# step 1
python3 1-filterMc3.py

# step 2.1
# download xGen Exome Research Panel target.bed manually
cut -f 1-3 xGen\ Exome\ Research\ Panel\ target.bed | \
  sed 's/chr//g' | \
  bedtools slop -b 50 -i - -g hs37d5.chrom.size.txt | \
  sort -k1V,1 -k2n,2 | bedtools merge -i - > flk50_idt.bed

# step 2.2
wget ftp://ftp.ensembl.org/pub/grch37/release-93/gtf/homo_sapiens/Homo_sapiens.GRCh37.87.gtf.gz
gunzip -c Homo_sapiens.GRCh37.87.gtf.gz | \
  awk -F '\t' '{if($1!~/#/ && $3=="CDS") print $1"\t"($4-1)"\t"$5"\t"$3"\t"$6"\t"$7}' Homo_sapiens.GRCh37.87.gtf | \
  bedtools slop -b 2 -i - -g hs37d5.chrom.size.txt | \
  sort -k1V,1 -k2n,2 | bedtools merge -i - > Homo_sapiens.GRCh37.87.v93_CDS.flk2.bed

# step 2.3
intersectBed -a flk50_idt.bed -b Homo_sapiens.GRCh37.87.v93_CDS.flk2.bed | \
  sort -k1V,1 -k2n,2 | bedtools merge -i - | \
  awk 'BEGIN{SUM=0} {SUM+=$3-$2} END{print SUM}'

# step 2.4
sh 2-restrainRegions.sh flk50_idt.bed > mc3.lite.idt_intersected.tsv

