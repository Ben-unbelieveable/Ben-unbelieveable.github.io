# `$0` - panel or WES bed file
head -n1 mc3.lite.tsv && sed '1d' mc3.lite.tsv|awk -F'\t' 'BEGIN{OFS="\t"}{print $1,$2-1,$3,$0}'|intersectBed -a - -b $1 -wa|sort -u|cut -f4-
